// document.querySelectorAll(".heading_tab_text").forEach((head) => {
//   head.addEventListener("click", (event) => {
//     let tabId = head.dataset.tab;
    
//     document
//       .querySelectorAll(".heading_tab_text")
//       .forEach((h) => h.classList.remove("is--active"));
//     document
//       .querySelectorAll(".custom_product_products_container")
//       .forEach((c) => c.classList.remove("is--active"));
//     head.classList.add("is--active");
//     document.getElementById(tabId).classList.add("is--active");
//   });
// });


// Get all the tab elements and product containers
const tabTextElements = document.querySelectorAll('.heading_tab_text');
const productContainers = document.querySelectorAll('.custom_product_products_container');

// Add click event listener to each tab text element
tabTextElements.forEach(tabTextElement => {
  tabTextElement.addEventListener('click', () => {
    // Get the data-tab value associated with the clicked tab
    const tabId = tabTextElement.getAttribute('data-tab');

    // Hide all product containers
    productContainers.forEach(container => {
      container.style.display = 'none';
    });

    // Show the product container associated with the clicked tab
    const targetProductContainer = document.querySelector(`[data-tab="${tabId}"]`);
    if (targetProductContainer) {
      targetProductContainer.style.display = 'block';
    }
  });
});
